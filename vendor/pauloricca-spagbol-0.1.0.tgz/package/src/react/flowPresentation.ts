import type { Edge, Node, NodeChange } from "@xyflow/react";
import type { Size } from "../core/index.js";

/** Apply measurement notifications without turning them into graph/history edits. */
export function rememberMeasurements<N extends Node>(
  cache: Map<string, Size>,
  changes: readonly NodeChange<N>[],
): boolean {
  let changed = false;
  for (const change of changes)
    if (change.type === "dimensions" && change.dimensions) {
      const previous = cache.get(change.id);
      if (
        previous?.width !== change.dimensions.width ||
        previous?.height !== change.dimensions.height
      ) {
        cache.set(change.id, { ...change.dimensions });
        changed = true;
      }
    }
  return changed;
}

/** React Flow hides the reconnecting edge; a separate identity keeps the source visible. */
export function stationaryReconnectEdge<E extends Edge>(edge: E): E {
  return {
    ...edge,
    id: `reconnect-preview:${edge.id}`,
    selected: false,
    reconnectable: false,
    selectable: false,
    focusable: false,
    deletable: false,
    data: { ...edge.data, emphasized: false, dimmed: false },
  };
}
